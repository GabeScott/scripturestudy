import json
import sys
import re
import base64

def setJsonFiles(booksToSearch):
    jsonFiles = []
    if "OT" in booksToSearch:
        jsonFiles.append('ot.json')
        
    if "NT" in booksToSearch:
        jsonFiles.append('nt.json')
        
    if "BOM" in booksToSearch:
        jsonFiles.append('bom.json')
        
    if "D&C" in booksToSearch:
        jsonFiles.append('dac.json')
        
    if "POGP" in booksToSearch:
        jsonFiles.append('pogp.json')
        
    return jsonFiles


def searchTermInText(text, searchTerms):
    for term in searchTerms:
        if len(re.findall(term, text, re.IGNORECASE)) > 0:
            return True
    return False


def countHits(text, searchTerms):
    localHits = 0
    for term in searchTerms:
        localHits += len(re.findall(term, text, re.IGNORECASE))
    return localHits


def simpleSearch(jsonFiles, searchTerms, startingPoint, responseSize):
    maxVerses = startingPoint + responseSize
    numVerses = 0
    results = {}
    hits = 0
    print(jsonFiles)
    for file in jsonFiles:
        with open(file) as f:
            allRefs = json.load(f)
            
        for book in allRefs:
            for chapter in allRefs[book]:
    
                if chapter == 'heading':
                    continue
    
                for verse in allRefs[book][chapter]:
                    verseText = allRefs[book][chapter][verse]
                    if searchTermInText(verseText, searchTerms):
                        numVerses += 1
                        if numVerses >= startingPoint and numVerses < maxVerses:
                            results[book + " " + chapter + ":" + verse] = verseText
                        hits += countHits(verseText, searchTerms)
    results['hits'] = hits
    return results
    

def lambda_handler(event, context):
    print(event)
    
    searchTerms = json.loads(event['body'])['searchTerms']
    startingPoint = json.loads(event['body'])['startingPoint']
    responseSize = json.loads(event['body'])['responseSize']
    jsonFiles = setJsonFiles(json.loads(event['body'])['booksToSearch'])
    #searchTerms = event['searchTerms']
    
    body = simpleSearch(jsonFiles, searchTerms, startingPoint, responseSize)
    
    body = json.dumps(body)
    

    retval = {
        'headers': {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": "Content-Type",
            "Access-Control-Allow-Methods": "POST",
            'Access-Control-Allow-Credentials': "true",
        },
        'statusCode': 200,
        'body': body
    }
    
    print(retval)
    
    return retval
