from git import Repo
from datetime import datetime, timedelta, timezone
import os
import subprocess
import boto3
import uuid


files_to_copy = ['main.js', 'index.html', 'styles.css', 'allbooks.js']

def lambda_handler(event, context):
    os.system("rm -rf /var/*")
    
    git_url = "https://github.com/GabeScott/scripturestudy.git"
    repo_dir = "/tmp/"+str(uuid.uuid4())+"/"
        
    os.mkdir(repo_dir)
    os.chdir(repo_dir)
    
    Repo.clone_from(git_url, repo_dir)
    
    output = subprocess.check_output(
        'git log -1 --format=%cd',
        shell=True,
    ).decode("utf-8").replace("\n", "") 
    
    print(output)
    
    latest_commit = datetime.strptime(output, '%a %b %d %H:%M:%S %Y %z')

    cur_time = datetime.now(timezone.utc)
    two_min_ago = datetime.now(timezone.utc) - timedelta(minutes=2)
    
    
    if two_min_ago < latest_commit < cur_time:
        s3 = boto3.resource('s3')
        
        for file in files_to_copy:
            if ".js" in file:
                content_type = "application/javascript"
            elif ".html" in file:
                content_type = "text/html"
            elif ".css" in file:
                content_type = "text/css"
            s3.meta.client.upload_file(repo_dir+file, 'gscott-website', file, ExtraArgs={'ContentType':content_type})
         
        return "Update Successful"
    return "No update necessary"