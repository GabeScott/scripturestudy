import json
import psycopg2
import datetime
import boto3

host = ""
database = "zettelkasten"
user="postgres"
password = "gamecubeking"


def get_username_id_from_name(name):
    conn = get_connection()

    sql = """
    SELECT name_id
    FROM usernames
    WHERE name = '{}';
    """

    cursor = conn.cursor()

    cursor.execute(sql.format(name))

    result = cursor.fetchone()

    conn.close()
    cursor.close()

    if result is not None:
        return result[0]
    else:
        return 0


def get_username_from_id(id):
    conn = get_connection()

    sql = """
    SELECT name
    FROM usernames
    WHERE name_id = '{}';
    """

    cursor = conn.cursor()

    cursor.execute(sql.format(id))

    result = cursor.fetchone()

    conn.close()
    cursor.close()

    if result is not None:
        return result[0]
    else:
        return ''

def is_valid_id(id):
    conn = get_connection()

    sql = """
    SELECT id
    FROM note
    WHERE id = '{}';
    """

    cursor = conn.cursor()

    cursor.execute(sql.format(id))

    result = cursor.fetchone()

    conn.close()
    cursor.close()

    return result is None


def get_next_id():
    date = datetime.datetime.now()

    year = str(date.year)
    month = '{:02}'.format(date.month)
    day = '{:02}'.format(date.day)

    id=year+month+day+"a"
    return id



def get_next_valid_id():
    conn = get_connection()
    potential_id = list(get_next_id())

    while not is_valid_id("".join(potential_id)):
        if potential_id[-1] == 'z':
            potential_id.append('a')
        else:
            potential_id[-1] = chr(ord(potential_id[-1]) + 1)

    return "".join(potential_id)


def get_creator_of_note(id):
    conn = get_connection()
    cursor = conn.cursor()

    sql= """
    SELECT created_by_id
    FROM note
    WHERE id = %s;
    """

    cursor.execute(sql, (id,))
    result = cursor.fetchone()

    cursor.close()
    conn.close()

    return get_username_from_id(result[0])


def get_owner_of_note(id):
    conn = get_connection()
    cursor = conn.cursor()

    sql= """
    SELECT owner
    FROM note
    WHERE id = %s;
    """

    cursor.execute(sql, (id,))
    result = cursor.fetchone()

    cursor.close()
    conn.close()

    return result[0]

def get_body_of_note(id):
    conn = get_connection()
    cursor = conn.cursor()

    sql= """
    SELECT body
    FROM note
    WHERE id = %s;
    """

    cursor.execute(sql, (id,))
    result = cursor.fetchone()

    cursor.close()
    conn.close()

    return result[0]


def get_tags_of_note(id):
    conn = get_connection()
    cursor = conn.cursor()

    sql= """
    SELECT tags
    FROM note
    WHERE id = %s;
    """

    cursor.execute(sql, (id,))
    result = cursor.fetchone()

    cursor.close()
    conn.close()

    return result[0]
    
def get_title_of_note(id):
    conn = get_connection()
    cursor = conn.cursor()

    sql= """
    SELECT title
    FROM note
    WHERE id = %s;
    """

    cursor.execute(sql, (id,))
    result = cursor.fetchone()

    cursor.close()
    conn.close()

    return result[0]

def get_connection():
    connection = psycopg2.connect(host=host,database=database, user=user, password=password)
    return connection
    
def create(request):
    body = request['body']
    tags = request['tags']
    owner = request['owner']
    creator = get_username_id_from_name(request['creator'])
    title = request['title']

    id = get_next_valid_id()

    sql="""
    INSERT INTO note (id, body, tags, owner, created_by_id, title) VALUES (%s, %s, %s, %s, %s, %s);
    """

    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute(sql, (id, body, tags, owner, creator, title))
    conn.commit()

    cursor.close()
    conn.close()

    return json.dumps({'id':id})
    
    
def getTags(request):
    print("getTags: "+host)
    user = get_username_id_from_name(request['user'])

    sql="""
    SELECT tags FROM note WHERE (created_by_id = %s or owner = 'public');
    """

    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute(sql, (user,))

    results = cursor.fetchall()

    cursor.close()
    conn.close()

    allTags = ""

    for tag in results:
        allTags += tag[0] + ", "

    tagList = allTags.split(", ")

    tagDict = {}

    for tag in tagList:
        tag = tag.lower()
        if len(tag) == 0:
            continue
        if tag not in tagDict.keys():
            tagDict[tag] = 1
        else:
            tagDict[tag] += 1
            
    # tagDict = sorted(tagDict)

    return json.dumps(tagDict)
    
    
    
    
def doesUserExist(request):
    user = request['user']

    sql="""
    SELECT name FROM usernames WHERE lower(name) = lower(%s);
    """

    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute(sql, (user,))

    cursor.close()
    conn.close()

    if cursor.rowcount > 0:
        return 'true'
    else:
        return 'false'
        
        

def edit(request):
    id = request['id']
    new_body = request['body']
    new_tags = request['tags']
    user = request['user']
    user_id = get_username_id_from_name(user)
    new_title = request['title']
    new_owner = request['owner']

    owner = get_owner_of_note(id)
    creator = get_creator_of_note(id)

    if owner == 'public' and creator != user:
        new_body = get_body_of_note(id) + "\n" + new_body if len(new_body) > 0 else get_body_of_note(id)
        new_tags = get_tags_of_note(id) + ", " + new_tags if len(new_tags) > 0 else get_tags_of_note(id)
        new_title = get_title_of_note(id) + " " + new_title if len(new_title) > 0 else get_title_of_note(id)


    sql="""
    UPDATE note SET body = %s, tags = %s, title = %s, owner = %s
    WHERE id = %s and (created_by_id = %s or owner='public');
    """

    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute(sql, (new_body, new_tags, new_title, new_owner, id, user_id))
    conn.commit()

    cursor.close()
    conn.close()

    if cursor.rowcount == 0:
        return json.dumps({"response":"Unable to edit or find note with id: " + id, "new_title":new_title, "new_body":new_body, "new_tags":new_tags})
    else:
        return json.dumps({"response":"Note " + id + " edited successfully", "new_title":new_title, "new_body":new_body, "new_tags":new_tags})
        
        
def searchById(request):
    id = request['id']
    user = request['user']
    user_id = get_username_id_from_name(user)
    
    print(user + " " + str(user_id))

    sql = """
    SELECT body, tags, title, owner
    FROM note
    WHERE id = %s and (owner = 'public' or created_by_id = %s);
    """

    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute(sql, (id, user_id))
    result = cursor.fetchone()

    cursor.close()
    conn.close()

    if result is None:
        return "NO NOTE FOUND WITH ID " + id

    return json.dumps({'body':result[0], 'tags':result[1], "title":result[2], "owner":result[3]})
    
    
    
    
def searchByTag(request):
    tag = request['tag']
    user = request['user']
    user_id = get_username_id_from_name(user)

    sql = """
    SELECT id, body, tags, title, owner
    FROM note
    WHERE position(LOWER(%s) in LOWER(tags))>0 and (owner = 'public' or created_by_id = %s);
    """

    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute(sql, (tag, user_id))
    result = cursor.fetchall()

    cursor.close()
    conn.close()

    if len(result) == 0:
        return "NO NOTE FOUND WITH TAG " + tag

    return_list = [(x[0], x[1], x[2], x[3], x[4]) for x in result]

    return json.dumps(return_list)

    
    
    
def searchByText(request):
    text = request['text']
    user = request['user']
    user_id = get_username_id_from_name(user)

    sql = """
    SELECT id, body, tags, title, owner
    FROM note
    WHERE (position(LOWER(%s) in LOWER(body))>0 or position(LOWER(%s) in LOWER(title))>0) and (owner = 'public' or created_by_id = %s);
    """

    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute(sql, (text, text, user_id))
    result = cursor.fetchall()

    cursor.close()
    conn.close()

    if len(result) == 0:
        return "NO NOTE FOUND WITH " + text + " IN BODY"

    return_list = [(x[0], x[1], x[2], x[3], x[4]) for x in result]

    return json.dumps(return_list)
    
    
    

def getPermissions(request):
    user = request['user']
    id = request['id']


    sql = """
    SELECT created_by_id, owner
    FROM note
    WHERE id = %s;
    """

    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute(sql, (id,))
    result = cursor.fetchone()

    cursor.close()
    conn.close()

 

    if result is None:
        return "d"

    elif get_username_from_id(result[0]) == user:
        return "e"

    elif result[1] == 'public':
        return "a"

    else:
        return "d"
        
        
def delete(request):
    id = request['id']
    user = request['user']
    user_id = get_username_id_from_name(user)

    sql="""
        DELETE FROM note
        WHERE id = %s and created_by_id = %s;
        """

    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute(sql, (id, user_id))

    conn.commit()
    cursor.close()
    conn.close()

    if cursor.rowcount == 0:
        return "NO NOTE FOUND WITH ID " + id + ", OR IT CANNOT BE DELETED"
    else:
        return "NOTE DELETED"
        
        
def showLdss(request):
    searchText = request['searchText']
    
    sql = """
    SELECT reference, content, comments
    FROM ldss
    WHERE LOWER(reference) = LOWER(%s);
    """
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute(sql, (searchText,))
    
    result = cursor.fetchone()

    cursor.close()
    conn.close()
    
    if result is None:
        return "Unable to find content matching " + searchText
    else:
        return_list = {"reference":result[0], "content":result[1], "comments":result[2]}
        return json.dumps(return_list)
        
        
        
def commentOnLdss(request):
    comment = request['comment']
    scripture = request['scripture']
    user = request['user']
    
    
    get_comment_sql = """
    SELECT comments
    FROM ldss
    WHERE LOWER(reference) = LOWER(%s);
    """
    
    insert_new_comment_sql = """
    UPDATE ldss
    SET comments = %s
    WHERE LOWER(reference) = LOWER(%s);
    """
    
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute(get_comment_sql, (scripture,))
    
    result = cursor.fetchone()
    new_comment = ""
    
    if len(result[0]) != 0:
        orig_comment = result[0]
        new_comment = orig_comment + "\n\n" + comment + "\nCommented by: " + user
    else:
        new_comment = comment + "\nCommented by: " + user
        
    cursor.execute(insert_new_comment_sql, (new_comment, scripture))
    
    
    conn.commit()
    

    cursor.close()
    conn.close()
    
    
    if cursor.rowcount == 0:
        return "Unable to enter comment"
    else:
        return "Comment entered successfully"
        
        
def count():
    sql = """
    SELECT count(title)
    FROM note;
    """
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute(sql)
    
    result = cursor.fetchone()

    cursor.close()
    conn.close()
    
    if result is None:
        return "Error counting notes"
    else:
        return result[0]
    
    
def test():
    ec2 = boto3.client('ec2', region_name='us-east-1')
    instance = ec2.describe_instances(InstanceIds=['i-0f51db467651e4d4e'])['Reservations'][0]['Instances'][0]
    status = instance['State']['Name']
    if status == 'running':
        host = instance['PublicIpAddress']
        return host
    return "False"


def lambda_handler(event, context):
    global host
    event = json.loads(event['body'])
    #event = event['body']

    action = event['action']
    host = event['dbHost']
    print(event)
    
    returnVal = "action not understood"
    try:
        if action == 'create':
            returnVal = create(event)
            
        elif action == 'getTags':
            returnVal = getTags(event)
            
        elif action == 'doesUserExist':
            returnVal = doesUserExist(event)
            
        elif action == 'edit':
            returnVal = edit(event)
            
        elif action == 'searchById':
            returnVal = searchById(event)
            
        elif action == 'searchByTag':
            returnVal = searchByTag(event)
            
        elif action == 'searchByText':
            returnVal = searchByText(event)
        
        elif action == 'getPermissions':
            returnVal = getPermissions(event)
            
        elif action == 'delete':
            returnVal = delete(event)
        
        elif action == 'showLdss':
            returnVal = showLdss(event)
            
        elif action == 'commentOnLdss':
            returnVal = commentOnLdss(event)
            
        elif action == 'count':
            returnVal = count()
            
        elif action == 'test':
            returnVal = test()
    except Exception as e:
        print(e)
        return {
        'headers': {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": "Content-Type",
            "Access-Control-Allow-Methods": "POST",
            'Access-Control-Allow-Credentials': "true",
        },
        'statusCode': 300,
        'body':'Internal Error'
        }
        
    response = {
        'headers': {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": "Content-Type",
            "Access-Control-Allow-Methods": "POST",
            'Access-Control-Allow-Credentials': "true",
        },
        'statusCode': 200,
        'body':returnVal
    }
    
    print(response)
    return response
    
